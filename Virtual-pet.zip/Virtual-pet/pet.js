let bloodthirst = 0;
let hunger = 0;

function feedpet() {
    console.log("Feeding pet...")
}