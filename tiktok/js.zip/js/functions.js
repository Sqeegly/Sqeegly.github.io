console.log("Hello world!");
// simple function, no parameters
function hello() {
        console.log("Hi Rami!");
    }
    function hello2(name) {
        console.log("Hi " + name);
    }
    hello();
    hello2("Akilesh");
    hello2("Jack");
 
    
    function square(x){
        p = x * x;
        return p;
    }
console.log(square(8));

function sumOfSqaure(x, y) {
    a = sqaure(x);
    b = sqaure(y);
    p = mathSum(a, b);
    return p;
}
console.log(sumOfSqaure(4, 2));

function hypo(x, y){
   c = sumOfSqaure(x , y);
   p = math.sqrt(c);
   return p; 
}
function annoyingGreet(name, x) {
    for (let i = 0; i < x; i++) {
        console.log("Whats up " + name + x)

    }
}


function mathSum(x, y) {
    let p = x + y;
    return p;
}

console.log(mathSum(4, 2));

function sqaure(x) {
    let p = x * x;
    return p;
}
annoyingGreet("fish", 100);


// tiktok's magic algorithm
// TODO: tweak algorith
// add at least two more new parameters
function magicAlgorithm(numLikes, comment) {
    let rank = 0;

    // magic!
    if (numLikes >= 10000 && comment.includes("dog")) {
        rank = 1;
    } else if (numLikes >= 500 && comment.includes("cat")) {
        rank = 100;
    } else {
        rank = 1000;
    }
    return rank;
}

alert("Hi, I hope you are doing well. Welcome to Tiktok! Let me show you something cool. Imagine I'm showing you a tiktok video right now");
let likeCount = Number(prompt("How many likes did this video get?"));
// ask for a video comment
let comment = prompt("What is the most recent comment for this video?");

// using the two inputs above
// pass that into the magic function and return the result in an alert popup
let rankResult = magicAlgorithm(likeCount, comment);
let resultString = "Based off of the magic algorithm, this video's rank is: " + rankResult;

alert(resultString);